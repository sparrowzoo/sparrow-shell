package org.adoptopenjdk.jitwatch.model.bytecode;

public class ConstantPool
{

}
