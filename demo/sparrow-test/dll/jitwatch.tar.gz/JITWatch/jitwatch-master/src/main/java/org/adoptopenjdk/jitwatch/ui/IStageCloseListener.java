package org.adoptopenjdk.jitwatch.ui;

import javafx.stage.Stage;

public interface IStageCloseListener
{
	void handleStageClosed(Stage stage);
}