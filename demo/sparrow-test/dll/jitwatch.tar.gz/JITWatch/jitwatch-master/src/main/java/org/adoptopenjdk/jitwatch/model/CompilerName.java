package org.adoptopenjdk.jitwatch.model;

public enum CompilerName
{
	C1, C2;
}
